import { Router } from "express"
import {
  register,
  login,
  getCurrentUser,
} from "../controllers/auth.controller.js"
import { requireAuth } from "../middlewares/auth.middleware.js"

const router = Router()

router.post("/register", register)
router.post("/login", login)
router.get("/me", requireAuth, getCurrentUser)

export default router
